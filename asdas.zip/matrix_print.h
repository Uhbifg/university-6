#ifndef MPI_MATRIX_MATRIX_PRINT_H
#define MPI_MATRIX_MATRIX_PRINT_H
void matrix_print(double *array, int n, int m, int flag, int *vec, int shift, int rank, int total_size, double *row_buffer);
#endif //MPI_MATRIX_MATRIX_PRINT_H
